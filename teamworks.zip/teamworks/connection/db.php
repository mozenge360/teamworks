<?php
/* Database connection settings */
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'realtorspage';
$mysqli = new mysqli($host,$user,$pass,$db) or die($mysqli->error);
global $mysqli;

$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'realtorspage';
$conn = new mysqli($host,$user,$pass,$db) or die($mysqli->error);
global $conn;

$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'realtorspage';
$conn_pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$conn_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
