 <!-- Classic Modal -->
  <div class="modal fade" id="feedBack" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn btn-warning"><span class="material-icons">queue</span> Add Note</button>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <i class="material-icons" style="color: red;">close</i>
          </button>
        </div>
        <div class="modal-body">
     
        <div class="description text-center">
          <p>An artist of considerable range, Chet Faker &#x2014; the name taken by Melbourne-raised, Brooklyn-based Nick Murphy &#x2014; writes, performs and records all of his own music, giving it a warm, intimate feel with a solid groove structure. </p>
        </div>
        </div>
        <div class="modal-footer">
          
          <button type="button" class="btn btn-danger btn-link" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
  <!--  End Modal -->