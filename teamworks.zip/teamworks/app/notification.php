 <!--        notifications -->
    <div class="section cd-section section-notifications" id="notifications">
      <div class="alert alert-success">
        <div class="container">
          <div class="alert-icon">
            <i class="material-icons">notification_important</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="material-icons">delete_sweep</i></span>
          </button>
          <b >New</b> you have <i class="badge btn-danger">(1)</i> calls to make...
        </div>
      </div>
      <div class="clearfix"></div>
    </div>
    <!--        end notifications -->