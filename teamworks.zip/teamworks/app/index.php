<?php 
 header("location: login-page.php");
?>