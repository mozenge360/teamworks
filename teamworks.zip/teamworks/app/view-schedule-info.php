<?php
  require('head-tag.php');
?>
<body class="profile-page sidebar-collapse">
<?php
  require('navigation-tag.php');
?>
  <div class="page-header header-filter" data-parallax="true" style="background-image: url('../assets/img/city-profile.jpg'); height: 150px;"></div>
  <div class="main main-raised">
    <div class="profile-content">
      <div class="container">
                        <?php
if(isset($_SESSION["email"])){

$id = $mysqli->escape_string($_GET["btn_id"]) ;

$sql = "SELECT * FROM contacts WHERE diary_owner='$profile_email' AND id=$id";
if($readme = mysqli_query($conn,$sql)){
$num = mysqli_num_rows($readme);
if($num > 0){

  while($list = mysqli_fetch_array($readme)){
    $id =$list["id"];
    $diary_owner = $list["diary_owner"];
    $contact_id = $list["contact_id"];           
    $contact_first_name = $list["contact_first_name"];
    $contact_last_name = $list["contact_last_name"];
    $company = $list["company"];
    $primary_phone = $list["phone_1"];
    $phone_2 = $list["phone_2"];
    $contact_email = $list["email"];
    $gender = $list["gender"];
    $note = $list["note"];
    $calls_count = $list["calls_count"];
    $contact_rating = $list["rating"];

      if ($contact_email == "") {
        $contact_email = "#";
      }
      if ($calls_count == "") {
        $calls_count = 0;
      }
      if ($contact_rating == "") {
        $contact_rating = "Rate Contact";
      }

    ?>

    <?php
}
}else{
echo "No record found!";
}

}else{
echo "Failed to query db!!";
}


}
else{
echo "Data failed";
}
?>
              <!-- Tabs with icons on Card -->
              <div class="card card-nav-tabs card-plain" style="widows: inherit;">
                <div class="card-header card-header-primary">
                  <div class="nav-tabs-navigation">
                    <div class="nav-tabs-wrapper">
                      <ul class="nav nav-tabs" data-tabs="tabs">
                        <li class="nav-item">
                          <a class="nav-link" href="work-area.php">
                            <i class="material-icons">arrow_left</i> Back
                          </a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="view-schedule-info.php?btn_id=<?php echo($id)?>">
                            <i class="material-icons">question_mark</i> Requests
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="card-body ">
                  <div class="tab-content text-center">
                    <div class="tab-pane active" id="profile">
                    <div class="card-body ">
         

<br><br><br>
    <div class="container">
        <div class="row">
          <div class="col-md-12 ml-auto mr-auto">
            <div class="profile">
                <a href="edit-contact.php?btn_id=<?php echo($id);?>" class="btn btn-default btn-link "><span class="material-icons"><?php echo date('D, d M - H:i:s A' , time());?></span></a>
            
                 <hr>

                
                <a href="tel:<?php echo "$primary_phone";?>"><button type="button" class="btn btn-info"><span class="material-icons">call</span> Call In</button></a>

                 <a href="add-note.php?btn_id=<?php echo($id);?>"><button type="button" class="btn btn-warning"><span class="material-icons">queue</span> Can't Make Shift</button></a>

               
              </div>
            </div>
          </div>
        </div>
        
      </div>
      
                    </div>
                  </div>
                </div>
 
                    </div>
                  </div>
                </div>
              </div>
              <!-- End Tabs with icons on Card -->
      </div>
    </div>
  </div>
 
<?php
//require "contact-detail-modal.php";
require 'view-note-modal.php';
require('js-files.php');
?>
</body>

</html>