<?php
if(isset($_SESSION["email"])){

$id = $mysqli->escape_string($_GET["btn_id"]) ;

$sql = "SELECT * FROM notes WHERE diary_owner='$profile_email' AND id=$id";
if($readme = mysqli_query($conn,$sql)){
$num = mysqli_num_rows($readme);
if($num > 0){

  while($list = mysqli_fetch_array($readme)){
    $id =$list["id"];
    $diary_owner = $list["diary_owner"];
    $contact_ids = $list["contact_id"];           
    $contact_notes = $list["note"];
    $contact_rate = $list["rating"];
    $date = $list["date"];

      if ($contact_rate == "") {
        $contact_rate = "Rate Contact";
      }elseif($contact_rate = "Good"){
        $contact_rate = '<span class="material-icons">checkbox</span> Good';
      }elseif($contact_rate = "Needs Follow Up"){
        $contact_rate = '<span class="material-icons">supervisor_account</span> Follow Up';
      }elseif($contact_rate = "Not Interested at this time"){
        $contact_rate = '<span class="material-icons">work_off</span> Not Available';
      }

    ?>

    <?php
}
}else{
echo "No record found!";
}

}else{
echo "Failed to query db!!";
}


}
else{
echo "Data failed";
}
?>