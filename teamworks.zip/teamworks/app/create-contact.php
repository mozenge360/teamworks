<?php
  require('head-tag.php');
?>
<body class="profile-page sidebar-collapse">
  <?php
  require('navigation-tag.php');
?>
  <div class="page-header header-filter" data-parallax="true" style="background-image: url('../assets/img/city-profile.jpg'); height: 150px;"></div>
  <div class="main main-raised">
    <div class="profile-content">
      <div class="container">
   

              <!-- Tabs with icons on Card -->
              <div class="card card-nav-tabs card-plain" style="widows: inherit;">
                <div class="card-header card-header-primary">
                  <!-- colors: "header-primary", "header-info", "header-success", "header-warning", "header-danger" -->
                  <div class="nav-tabs-navigation">
                    <div class="nav-tabs-wrapper">
                      <ul class="nav nav-tabs" data-tabs="tabs">
                        <li class="nav-item">
                          <a class="nav-link" href="contact.php">
                            <i class="material-icons">arrow_left</i> Back
                          </a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link active" href="#profile" data-toggle="tab">
                            <i class="material-icons">person_add</i>New Contact
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="card-body ">
                  <div class="tab-content text-center">
                    <div class="tab-pane active" id="profile">
<?php
/* Registration process, inserts user info into the database 
   and sends account confirmation email message
 */
if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
    if (isset($_POST['add_contact'])) {

// Escape all $_POST variables to protect against SQL injections
$contact_id = $mysqli->escape_string($_POST['contact_id']);
$first_name = $mysqli->escape_string($_POST['first_name']);
$last_name = $mysqli->escape_string($_POST['last_name']);
$company = $mysqli->escape_string($_POST['company']);
$phone_number1 = $mysqli->escape_string($_POST['phone_one']);
$phone_number2 = $mysqli->escape_string($_POST['phone_two']);
$contact_email = $mysqli->escape_string($_POST['contact_email']);
$gender = $mysqli->escape_string($_POST['gender']);
$notes = $mysqli->escape_string($_POST['notes']);
$diary_owner = $profile_email;


//$passwordo = $mysqli->escape_string(password_hash($_POST['password'], PASSWORD_BCRYPT));
//$hasho = $mysqli->escape_string( md5( rand(0,1000) ) );
    

  //  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);  
// Check if user with that email already exists
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
              // set the PDO error mode to exception
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$sql = "SELECT * FROM contacts WHERE phone_1='$phone_number1' || phone_1='$phone_number2'";

$result = $mysqli->query($sql) or die($mysqli->error());
// We know user number exists if the rows Discharged are more than 0
//$count = mysqli_num_rows($result);
if (mysqli_num_rows($result) > 0 ) {
    
?>
<div class="section cd-section section-notifications" id="notifications">
      <div class="alert alert-danger">
        <div class="container">
          <div class="alert-icon">
            <i class="material-icons">notification_important</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="material-icons">delete_sweep</i></span>
          </button>
          <b>Phone Number already exists in diary...</b>
        </div>
      </div>
<?php
}
else { 

    try {
              $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
              // set the PDO error mode to exception
              $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
              $sql = "INSERT INTO contacts (diary_owner, contact_id, contact_first_name, contact_last_name, company, phone_1, phone_2, enali, gender, note)
              VALUES ('$diary_owner', '$contact_id', '$first_name', '$last_name', '$company', '$phone_number1', '$phone_number2', '$contact_email', '$gender', '$notes')";
?>
<div class="section cd-section section-notifications" id="notifications">
      <div class="alert alert-success">
        <div class="container">
          <div class="alert-icon">
            <i class="material-icons">notification_important</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="material-icons">delete_sweep</i></span>
          </button>

          <b>New Contact <?php echo " $first_name". " added Successfully"; ?></b>
        </div>
      </div>
<?php
              $conn->exec($sql);
 
              }
            catch(PDOException $e)
              {
              echo $sql . "<br>" . $e->getMessage();
              }

            $conn = null;
          

    }

}
}
?>

    
  <div class="container-fluid">
  <div class="row">
                      <div class="col-lg-6 col-sm-6">
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST" enctype="multipart/form-data" >
                           <input name="contact_id" class="form-control form-group" type="hidden" value="<?php echo("RTP/" . mt_rand());?>"></br>
              <div class="form-group">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">person</i>
                    </span>
                  </div>
                  <input type="text" class="form-control" name="first_name" placeholder="First Name" required>
                </div>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">person</i>
                    </span>
                  </div>
                  <input type="text" class="form-control" name="last_name" placeholder="Last Name" required>
                </div>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">house</i>
                    </span>
                  </div>
                  <input type="text" class="form-control" name="company" placeholder="Where does your contact work?">
                </div>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">mobile_screen_share</i>
                    </span>
                  </div>
                  <input type="number" class="form-control" name="phone_one" placeholder="000-0000-000" required>
                </div>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">phone</i>
                    </span>
                  </div>
                  <input type="number" class="form-control" name="phone_two" placeholder="000-0000-000">
                </div>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">email</i>
                    </span>
                  </div>
                  <input type="email" class="form-control" name="contact_email" placeholder="your@email.com">
                </div>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">supervisor_account</i>
                    </span>
                  </div>
                  <select class="form-control" type="text" name="gender">
                    <option value="Non Selected">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>

                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">add_comment</i>
                    </span>
                  </div>
                  <textarea class="form-control" name="notes" placeholder="Start taking Note..."></textarea><hr>
                  
                </div><hr>
                <div class="text-center">
                <button type="submit" name="add_contact" class="btn btn-primary btn-block btn-lg" value="login"><span class="material-icons">person_add</span> Save Contact</button>
                </div>

                
                </div>
              </form>
              </div>

              <div class="col-lg-6 col-sm-6">
                
                
                        
              </div>
              </div>
</div>
            </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- End Tabs with icons on Card -->
      </div>
    </div>
  </div>
 <?php
//require "contact-detail-modal.php";
require 'view-note-modal.php';
require('js-files.php');
?>
</body>

</html>