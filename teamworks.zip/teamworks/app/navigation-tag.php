<nav class="navbar navbar-transparent navbar-color-on-scroll fixed-top navbar-expand-lg" color-on-scroll="100" id="sectionsNav">
    <div class="container">
      <div class="navbar-translate">
        <a class="navbar-brand" href="#">
          TeamWorks </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="sr-only">Toggle navigation</span>
          <span class="navbar-toggler-icon"></span>
          <span class="navbar-toggler-icon"></span>
          <span class="navbar-toggler-icon"></span>
        </button>
      </div>
      <div class="collapse navbar-collapse">
        <ul class="navbar-nav ml-auto">
          <li class="dropdown nav-item">
            <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
              <i class="material-icons">apps</i> Components
            </a>
            <div class="dropdown-menu dropdown-with-icons">
              <a href="../index.html" class="dropdown-item">
                <i class="material-icons">layers</i> All Components
              </a>
              <a href="#" class="dropdown-item">
                <i class="material-icons">content_paste</i> Documentation
              </a>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link">
              <i class="material-icons">download</i> 
            </a>
          </li>
          <?php
            if ( $_SESSION['logged_in'] != 1 ) 
            {
                ?>
          <li class="nav-item">
            <a class="nav-link" href="signup-page.php">
              <i class="material-icons">add_box</i> Sign Up
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="login-page.php">
              <i class="material-icons">lock_open</i> Sign In
            </a>
          </li>
                <?php
            }else
            {
                ?>

          <li class="nav-item">
            <a class="nav-link" href="dashboard.php">
              <i class="material-icons">dashboard</i> Dashboard
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="work-area.php">
              <i class="material-icons">work</i> Work Area
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="create-contact.php">
              <i class="material-icons">person</i> New Contact
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="contact.php">
              <i class="material-icons">person</i> Contacts
            </a>
          </li>
          
         <!-- <li class="nav-item">
            <a class="nav-link" href="add-note.php">
              <i class="material-icons">add_comment</i> Add Note
            </a>
          </li>-->
                  <li class="nav-item">
            <a class="nav-link" href="my-profile.php">
              <i class="material-icons">person_pin</i> Profile
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="login-page.php">
              <i class="material-icons">power_settings_new</i> Logout
            </a>
          </li>
                <?php
            }
          ?>
          
          
        </ul>
      </div>
    </div>
  </nav>