<?php
  require('head-tag.php');
?>
                               <?php
if(isset($_SESSION["email"])){

$id = $mysqli->escape_string($_GET["btn_id"]) ;

$sql = "SELECT * FROM contacts WHERE diary_owner='$profile_email' AND id=$id";
if($readme = mysqli_query($conn,$sql)){
$num = mysqli_num_rows($readme);
if($num > 0){

  while($list = mysqli_fetch_array($readme)){
    $id =$list["id"];
    $diary_owner = $list["diary_owner"];
    $contact_id = $list["contact_id"];           
    $contact_first_name = $list["contact_first_name"];
    $contact_last_name = $list["contact_last_name"];
    $company = $list["company"];
    $primary_phone = $list["phone_1"];
    $phone_2 = $list["phone_2"];
    $contact_email = $list["email"];
    $gender = $list["gender"];
    $note = $list["note"];
    $calls_count = $list["calls_count"];
    $contact_rating = $list["rating"];

      if ($contact_email == "") {
        $contact_email = "#";
      }
      if ($calls_count == "") {
        $calls_count = 0;
      }
      if ($contact_rating == "") {
        $contact_rating = "Rate Contact";
      }

    ?>

    <?php
}
}else{
echo "No record found!";
}

}else{
echo "Failed to query db!!";
}


}
else{
echo "Data failed";
}
?>
<style type="text/css">
  .contact-card{
    padding-left: 1px;
    text-align: left;
  }
  .contact-option{
    text-align: right;
  }
</style>

<body class="profile-page sidebar-collapse">
  <?php
  require('navigation-tag.php');
?>
  <div class="page-header header-filter" data-parallax="true" style="background-image: url('../assets/img/city-profile.jpg'); height: 150px;"></div>
  <div class="main main-raised">
    <div class="profile-content">
      <div class="container">

 
   

              <!-- Tabs with icons on Card -->
              <div class="card card-nav-tabs card-plain" style="widows: inherit;">
                <div class="card-header card-header-primary">
                  <!-- colors: "header-primary", "header-info", "header-success", "header-warning", "header-danger" -->
                  <div class="nav-tabs-navigation">
                    <div class="nav-tabs-wrapper">
                      <ul class="nav nav-tabs" data-tabs="tabs">
                        <li class="nav-item">
                          <a class="nav-link" href="view-contact-info.php?btn_id=<?php echo($id);?>">
                            <i class="material-icons">arrow_left</i> Back
                          </a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link active" href="#profile" data-toggle="tab">
                            <i class="material-icons">add_comment</i>Create New Note 
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="card-body ">
                  <div class="tab-content text-center">
                    <div class="tab-pane active" id="profile">
                      <div class="col-lg-6 col-sm-6">
                         <a href="notes-view.php?btn_id=<?php echo($id)?>"><button type="button" class="btn btn-info"><span class="material-icons">note</span> Make Request</button></a>
                  <?php include  'action-send-note.php' ;?>

              <form action="add-note.php?btn_id=<?php echo($id)?>" method="POST" enctype="multipart/form-data" >
                  <input name="contact_id" class="form-control form-group" type="hidden" value="<?php echo("RTP/" . mt_rand());?>">

            <div class="col-md-12">
              <div class="title">

                  <hr>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">person</i>
                    </span>
                  </div>
                  <select class="form-control" name="contact_id">
                   <option value= "<?php echo $id;?>"><?php echo "$contact_first_name".' '."$contact_last_name";?></option>
                  </select>
                </div>

                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">note_add</i>
                    </span>
                  </div>
                  <textarea class="form-control" name="note_added" placeholder="Start taking Note..."></textarea>
                </div>
                 <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">star_border</i>
                    </span>
                  </div>
                  <select class="form-control" name="contact_rate">
                    <option value="No Rating">Rate Feedback</option>
                    <option value="Good">Good </option>
                    <option value="Needs Follow Up">Needs Follow Up</option>
                    <option value="Not Interested at this time">Not Interested at this time </option>
                  </select>
                </div>
                <button type="submit" class="btn btn-success" name="add_note"><span class="material-icons" >add_comment</span> Save Note</button>
            </form>
              </div>
            </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- End Tabs with icons on Card -->
      </div>
    </div>
  </div>
<?php
  require('js-files.php');
?>
</body>

</html>