<?php
  require('head-tag.php');
?>

<body class="login-page sidebar-collapse">
<?php
  //require('navigation-tag.php');
?>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
    if (isset($_POST['register'])) {

// Escape all $_POST variables to protect against SQL injections
$first_name = $mysqli->escape_string($_POST['first_name']);
$email = $mysqli->escape_string($_POST['email']);

$password = $mysqli->escape_string(password_hash($_POST['password'], PASSWORD_BCRYPT));
$hash_key = $mysqli->escape_string( md5( rand(0,1000) ) );
      
// Check if user with that email already exists
$result = $mysqli->query("SELECT * FROM users WHERE email='$email'") or die($mysqli->error());

// We know user email exists if the rows Discharged are more than 0
if ( $result->num_rows > 0 ) {
    
?>
<div class="section cd-section section-notifications" id="notifications">
      <div class="alert alert-warning">
        <div class="container">
          <div class="alert-icon">
            <i class="material-icons">sentiment_very_dissatisfied</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="material-icons">delete_sweep</i></span>
          </button>
          <b>User alreeady has a page with Realtors page... <a href="login-page.php"><button class="btn btn-primary">Login</button></a> </b>
        </div>
      </div>
    </div>
<?php
}
else { 
    try {
              // set the PDO error mode to exception
              $conn_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
              $sql = "INSERT INTO users (first_name, email, password, hash)
              VALUES ('$first_name', '$email', '$password', '$hash_key')";
             $conn_pdo->exec($sql);
              ?>
<div class="section cd-section section-notifications" id="notifications">
      <div class="alert alert-success">
        <div class="container">
          <div class="alert-icon">
            <i class="material-icons">add_alert</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="material-icons">delete_sweep</i></span>
          </button>

          <b>Welcome!! <?php echo "$first_name"; ?> Your page has been created.</b>
        </div>
      </div>
    </div>
              <?php
 
              }
            catch(PDOException $e)
              {
              echo $sql . "<br>" . $e->getMessage();
              }

            $conn_pdo = null;
          

    }

}
}
?>
  <div class="page-header header-filter" style="background-image: url('../assets/img/bg7.jpg'); background-size: cover; background-position: top center;">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-6 ml-auto mr-auto">
          <div class="card card-login">
            <form class="form" method="POST" action="signup-page.php">
              <div class="card-header card-header-rose text-center">
                <h4 class="card-title">Sign Up on RealtorsPage</h4>
                
                <!--<div class="social-line">
                  <a href="#pablo" class="btn btn-just-icon btn-link">
                    <i class="fa fa-facebook-square"></i>
                  </a>
                  <a href="#pablo" class="btn btn-just-icon btn-link">
                    <i class="fa fa-twitter"></i>
                  </a>
                  <a href="#pablo" class="btn btn-just-icon btn-link">
                    <i class="fa fa-google-plus"></i>
                  </a>
                </div>-->
              </div>
              <p class="description text-center">Or Be Classical</p>
              <div class="card-body">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">face</i>
                    </span>
                  </div>
                  <input type="text" class="form-control" placeholder="First Name..." name="first_name">
                </div>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">mail</i>
                    </span>
                  </div>
                  <input type="email" class="form-control" placeholder="Email..." name="email">
                </div>9*
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">lock_outline</i>
                    </span>
                  </div>
                  <input type="password" class="form-control" placeholder="Password..." name="password">
                </div>
              </div>
              <div class="footer text-center">
                <a href="login-page.php" class="btn btn-default btn-block btn-wd btn-lg">Already Signup? Login</a>
              </div>
              <div class="text-center">
                <button class="btn btn-rose btn-block btn-lg" type="submit" name="register">Sign Me Up</button>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div> 
  </div>
<?php
  require('js-files.php');
?>  
</body>

</html>