<?php
  require('head-tag.php');
?>
<style type="text/css">
  .contact-card{
    padding-left: 1px;
    text-align: left;
  }
  .contact-option{
    text-align: right;
  }
</style>

<body class="profile-page sidebar-collapse">
  <?php
  include ('navigation-tag.php');
?>
  <div class="page-header header-filter" data-parallax="true" style="background-image: url('../assets/img/city-profile.jpg'); height: 150px;"></div>
  <div class="main main-raised">
    <div class="profile-content">
      <div class="container">
   

              <!-- Tabs with icons on Card -->
              <div class="card card-nav-tabs card-plain" style="widows: inherit;">
                <div class="card-header card-header-primary">
                  <div class="nav-tabs-navigation">
                    <div class="nav-tabs-wrapper">
                      <ul class="nav nav-tabs" data-tabs="tabs">
                        <li class="nav-item">
                          <a class="nav-link" href="dashboard.php">
                            <i class="material-icons">dashboard</i> Home
                          </a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link active" href="#profile" data-toggle="tab">
                            <i class="material-icons">comment</i>My Shifts
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="card-body ">
                  <div class="tab-content text-center">
                    <div class="tab-pane active" id="profile">
                     <?php include("schedule-card.php");?>
                    </div>
                  </div>
                </div>
              </div>
              <!-- End Tabs with icons on Card -->
      </div>
    </div>
  </div>
<?php
//require "contact-detail-modal.php";
//require 'view-note-modal.php';
require('js-files.php');
?>
</body>

</html>