<?php
if(isset($_SESSION["email"])){

$sql = "SELECT * FROM contacts WHERE diary_owner='$profile_email'";
if($readme = mysqli_query($conn,$sql)){
$num = mysqli_num_rows($readme);
if($num > 0){

  while($list = mysqli_fetch_array($readme)){
    $id =$list["id"];
    $diary_owner = $list["diary_owner"];
    $contact_id = $list["contact_id"];           
    $contact_first_name = $list["contact_first_name"];
    $contact_last_name = $list["contact_last_name"];
    $company = $list["company"];
    $primary_phone = $list["phone_1"];
    $phone_2 = $list["phone_2"];
    $contact_email = $list["email"];
    $gender = $list["gender"];
    $note = $list["note"];
    $calls_count = $list["calls_count"];
    $contact_rating = $list["rating"];

      if ($contact_email == "") {
        $contact_email = "#";
      }
      if ($calls_count == "") {
        $calls_count = 0;
      }
      if ($contact_rating == "") {
        $contact_rating = "Rate Contact";
      }

    ?>
      <a class="nav-link" href="view-contact-info.php?btn_id=<?php echo($id)?>">
        <button type="submit" class="btn btn-default btn-block contact-card" data-toggle="modal" name="btn_code">
      <span class="material-icons" style="font-size: 25pt;">calendar</span>
      <span>Friday 25, April 2019 </span> - <span>9:00 PM - 05:00 PM</span>
    </button>
  </a>
       
     </form>
    <?php
}
}else{
echo "You do not have any contacts yet, Add Contact!";
}

}else{
echo "Failed to query db!!";
}


}
else{
echo "Data failed";
}
?>