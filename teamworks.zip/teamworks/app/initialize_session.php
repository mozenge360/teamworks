<?php
/* Displays user information and some useful messages */
session_start();
//error_reporting(E_ALL ^ E_NOTICE);

// Check if user is logged in using the session variable
if ( $_SESSION['logged_in'] != true ) {
 $_SESSION['message'] = "Log in to get started!";
  //header("location: login-page.php"); 
 ?>

<div class="section cd-section section-notifications" id="notifications">
      <div class="alert alert-danger text-center">
        <div class="container">
          <div class="alert-icon">
            <i class="material-icons">notification_important</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="material-icons">delete_sweep</i></span>
          </button>
          <b><?php echo $_SESSION['message'];?></b>
        </div>
      </div>
<?php
}
else {
    // Makes it easier to read with variable names
 $profile_image = $_SESSION['picture'];
 $profile_email = $_SESSION['email'];
  $user_title = $_SESSION['title'];
 $first_name = $_SESSION['first_name'];
 $middle_name = $_SESSION['middle_name'];
  $last_name = $_SESSION['phone'];
 $last_name = $_SESSION['last_name'];
 $active = $_SESSION['active'];
 $user_type = $_SESSION['user_type'];
 $user_id = $_SESSION['user_id'];
 $identification_user = $_SESSION['identification'];

 $user_dept = $_SESSION['department'];

 $current_month = date('F');
 $current_year = date('Y');

GLOBAL $profile_image;
GLOBAL $profile_email;
GLOBAL $first_name;
GLOBAL $last_name;
GLOBAL $middle_name;
GLOBAL $active;
GLOBAL $user_type;
GLOBAL $user_id;
GLOBAL $user_dept; 

}

?>




