<?php
  require('head-tag.php');
?>
<body class="profile-page sidebar-collapse">
<?php
  require('navigation-tag.php');
?>
  <div class="page-header header-filter" data-parallax="true" style="background-image: url('../assets/img/city-profile.jpg'); height: 150px;"></div>
  <div class="main main-raised">
    <div class="profile-content">
      <div class="container">
                        <?php
if(isset($_SESSION["email"])){

$id = $mysqli->escape_string($_GET["btn_id"]) ;

$sql = "SELECT * FROM contacts WHERE diary_owner='$profile_email' AND id=$id";
if($readme = mysqli_query($conn,$sql)){
$num = mysqli_num_rows($readme);
if($num > 0){

  while($list = mysqli_fetch_array($readme)){
    $id =$list["id"];
    $diary_owner = $list["diary_owner"];
    $contact_id = $list["contact_id"];           
    $contact_first_name = $list["contact_first_name"];
    $contact_last_name = $list["contact_last_name"];
    $company = $list["company"];
    $primary_phone = $list["phone_1"];
    $phone_2 = $list["phone_2"];
    $contact_email = $list["email"];
    $gender = $list["gender"];
    $note = $list["note"];
    $calls_count = $list["calls_count"];
    $contact_rating = $list["rating"];

      if ($contact_email == "") {
        $contact_email = "#";
      }
      if ($calls_count == "") {
        $calls_count = 0;
      }
      if ($contact_rating == "") {
        $contact_rating = "Rate Contact";
      }

    ?>

    <?php
}
}else{
echo "No record found!";
}

}else{
echo "Failed to query db!!";
}


}
else{
echo "Data failed";
}
?>
              <!-- Tabs with icons on Card -->
              <div class="card card-nav-tabs card-plain" style="widows: inherit;">
                <div class="card-header card-header-primary">
                  <div class="nav-tabs-navigation">
                    <div class="nav-tabs-wrapper">
                      <ul class="nav nav-tabs" data-tabs="tabs">
                        <li class="nav-item">
                          <a class="nav-link" href="contact.php">
                            <i class="material-icons">arrow_left</i> Back
                          </a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="notes-view.php?btn_id=<?php echo($id)?>">
                            <i class="material-icons">note</i> Notes
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="card-body ">
                  <div class="tab-content text-center">
                    <div class="tab-pane active" id="profile">
                    <div class="card-body ">
                  <div class="tab-content text-center">
                    <div class="tab-pane active" id="profile">
         

<br><br><br>
    <div class="container">
        <div class="row">
          <div class="col-md-12 ml-auto mr-auto">
            <div class="profile">
              <div class="avatar">
                <img src="../assets/img/faces/christian.jpg" alt="Circle Image" class="img-raised rounded-circle img-fluid">
              </div>
              <div class="name">
                <h3 class="title"><?php echo "$contact_first_name $contact_last_name"; ?></h3>
                <h6><?php echo "$primary_phone $contact_email"; ?></h6>
                <a href="tel:<?php echo "$primary_phone";?>"><button type="button" class="btn btn-info"><span class="material-icons">call</span> Call</button></a>
                <a href="mailto:<?php echo "$contact_email";?>"><button type="button" class="btn btn-primary"><span class="material-icons">contact_mail</span> e-Mail</button></a>

                 <a href="https://api.whatsapp.com/send?phone=<?php echo($primary_phone);?>&textHi, how are you today" class="social-icon whatsapp"><button type="button" class="btn btn-success"><span class="material-icons">send</span> WhatsApp</button></a>

                 <a href="add-note.php?btn_id=<?php echo($id);?>"><button type="button" class="btn btn-warning"><span class="material-icons">queue</span> Add Note</button></a>

                <hr>

                <a href="edit-contact.php?btn_id=<?php echo($id);?>" class="btn btn-just-icon btn-link "><span class="material-icons">edit</span></a>
                <a href="#pablo" class="btn btn-just-icon btn-link "><span class="material-icons">delete</span></a>
                <a href="#pablo" class="btn btn-just-icon btn-link"><span class="material-icons">alarm</span></a>
              </div>
            </div>
          </div>
        </div>
        
      </div>
      
                    </div>
                  </div>
                </div>
 
                    </div>
                    <div class="tab-pane" id="messages">
                      <?php include('retrieve-notes-for-contact.php');?>
                      <div class="description text-center">
                        <button type="button" class="btn btn-warning"><span class="material-icons">note</span> Add Note</button>
                        <hr>
                        <p>All Notes taken for <?php echo "$contact_first_name"; ?> will appear here...</p>
                        <p><?php echo "$note";?></p>
                        <hr>
                        <div class="description text-center">
                        <p><?php echo "$contact_notes";?></p>
                        <div class="tim-typo">
              <p>
                <span class="tim-note"><?php echo "$date";?></span>
                <?php echo "$contact_notes";?></p>
            </div>
            <div class="tim-typo">
              <span class="tim-note">Quote</span>
              <div class="blockquote undefined">
                <p>
                  I will be the leader of a company that ends up being worth billions of dollars, because I got the answers. I understand culture. I am the nucleus. I think that&#x2019;s a responsibility that I have, to push possibilities, to show people, this is the level that things could be at.
                </p>
                <small>
                  Kanye West, Musician
                </small>
              </div>
            </div>
                        <div class="modal-footer">
          
                        <button type="button" class="btn btn-danger btn-link"><?php echo "$contact_rate";?></button>
                      </div>
                      </div>
                      </div>
                      
                  

                    </div>
                  </div>
                </div>
              </div>
              <!-- End Tabs with icons on Card -->
      </div>
    </div>
  </div>
 
<?php
//require "contact-detail-modal.php";
require 'view-note-modal.php';
require('js-files.php');
?>
</body>

</html>