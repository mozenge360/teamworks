<?php
if(isset($_SESSION["email"])){

$sql = "SELECT * FROM notes WHERE user_email='$profile_email' AND ratings='Good'";
if($readme = mysqli_query($conn,$sql)){
$num = mysqli_num_rows($readme);
if($num > 0){

  while($list = mysqli_fetch_array($readme)){
    $diary_owner = $list["user_email"];
    $id = $list["contact_id"];           
    $contact_notes = $list["notes"];
    $contact_rate = $list["ratings"];
    $date = $list["date_time"];

      if ($contact_rate === "") {
        $contact_rate = "Rate Contact";
      }elseif($contact_rate === "Good"){
        $contact_rate = '<span class="material-icons" style="color:white;">checkbox</span>';
      }elseif($contact_rate === "Needs Follow Up"){
        $contact_rate = '<span class="material-icons"  style="color:orange;">report_off</span>';
      }elseif($contact_rate === "Not Interested at this time"){
        $contact_rate = '<span class="material-icons"  style="color:black;">work_off</span>';
      }

    ?>
  <a class="nav-link" href="notes-view.php?btn_id=<?php echo($id)?>">
    <button type="submit" class="btn btn-success btn-block contact-card" name="btn_code">
      <span class="material-icons" style="font-size: 25pt;">comment</span>
      <span> <?php echo date('D, d M Y H:i:s A' , time($date));?> </span> - <span><?php echo "$contact_rate"; ?></span>
    </button>
  </a>
    <?php
}
}else{
//echo "No record found!";
}

}else{
echo "Failed to query db!!";
}


}
else{
echo "Data failed";
}
?>