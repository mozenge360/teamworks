         
                <?php
if(isset($_SESSION["email"])){

$id = $mysqli->escape_string($_GET["btn_id"]) ;

$sql = "SELECT * FROM contacts WHERE diary_owner='$profile_email' AND id=$id";
if($readme = mysqli_query($conn,$sql)){
$num = mysqli_num_rows($readme);
if($num > 0){

  while($list = mysqli_fetch_array($readme)){
    $id =$list["id"];
    $diary_owner = $list["diary_owner"];
    $contact_id = $list["contact_id"];           
    $contact_first_name = $list["contact_first_name"];
    $contact_last_name = $list["contact_last_name"];
    $company = $list["company"];
    $primary_phone = $list["phone_1"];
    $phone_2 = $list["phone_2"];
    $contact_email = $list["email"];
    $gender = $list["gender"];
    $note = $list["note"];
    $calls_count = $list["calls_count"];
    $contact_rating = $list["rating"];

      if ($contact_email == "") {
        $contact_email = "#";
      }
      if ($calls_count == "") {
        $calls_count = 0;
      }
      if ($contact_rating == "") {
        $contact_rating = "Rate Contact";
      }

    ?>

    <?php
}
}else{
echo "No record found!";
}

}else{
echo "Failed to query db!!";
}


}
else{
echo "Data failed";
}
?>
 <!-- Classic Modal -->
  <div class="modal fade" id="myModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <i class="material-icons" style="color: red;">close</i>
          </button>
        </div>
        <div class="modal-body">
    <div class="container">
        <div class="row">
          <div class="col-md-12 ml-auto mr-auto">
            <div class="profile">
              <div class="avatar">
                <img src="../assets/img/faces/christian.jpg" alt="Circle Image" class="img-raised rounded-circle img-fluid">
              </div>
              <div class="name">
                <h3 class="title"><?php echo "$contact_first_name $contact_last_name"; ?></h3>
                <h6><?php echo "$primary_phone"; ?></h6>
                <a href="tel:<?php echo "$primary_phone";?>"><button type="button" class="btn btn-success"><span class="material-icons">call</span> Call</button></a>
                <a href="mailto:<?php echo "$contact_email";?>"><button type="button" class="btn btn-primary"><span class="material-icons">contact_mail</span> e-Mail</button></a><a href="add-note.php"><button type="button" class="btn btn-warning"><span class="material-icons">queue</span> Add Note</button></a><hr>
                <a href="#pablo" class="btn btn-just-icon btn-link btn-dribbble"><i class="fa fa-dribbble"></i></a>
                <a href="#pablo" class="btn btn-just-icon btn-link btn-twitter"><i class="fa fa-twitter"></i></a>
                <a href="#pablo" class="btn btn-just-icon btn-link btn-pinterest"><i class="fa fa-pinterest"></i></a>
              </div>
            </div>
          </div>
        </div>
        <div class="description text-center">
          <h3>Note</h3>
          <p><?php echo "$note";?></p>
        </div>
      </div>
        </div>
        <div class="modal-footer">
          <p><?php echo "$contact_rating";?></p>
          <button type="button" class="btn btn-danger btn-link" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
  <!--  End Modal -->