<?php
  require('head-tag.php');
?>
<body class="profile-page sidebar-collapse">
  <?php
  require('navigation-tag.php');
?>
                        <?php
if(isset($_SESSION["email"])){

$btn_id = $mysqli->escape_string($_GET["btn_id"]) ;

$sql = "SELECT * FROM contacts WHERE diary_owner='$profile_email' AND id=$btn_id";
if($readme = mysqli_query($conn,$sql)){
$num = mysqli_num_rows($readme);
if($num > 0){

  while($list = mysqli_fetch_array($readme)){
    $id =$list["id"];
    $diary_owner = $list["diary_owner"];
    $contact_id = $list["contact_id"];           
    $contact_first_name = $list["contact_first_name"];
    $contact_last_name = $list["contact_last_name"];
    $company = $list["company"];
    $primary_phone = $list["phone_1"];
    $phone_2 = $list["phone_2"];
    $contact_email = $list["email"];
    $gender = $list["gender"];
    $note = $list["note"];
    $calls_count = $list["calls_count"];
    $contact_rating = $list["rating"];

      if ($contact_email == "") {
        $contact_email = "#";
      }
      if ($calls_count == "") {
        $calls_count = 0;
      }
      if ($contact_rating == "") {
        $contact_rating = "Rate Contact";
      }

    ?>

    <?php
}
}else{
echo "No record found!";
}

}else{
echo "Failed to query db!!";
}


}
else{
echo "Data failed";
}
?>
  <div class="page-header header-filter" data-parallax="true" style="background-image: url('../assets/img/city-profile.jpg'); height: 150px;"></div>
  <div class="main main-raised">
    <div class="profile-content">
      <div class="container">
   

              <!-- Tabs with icons on Card -->
              <div class="card card-nav-tabs card-plain" style="widows: inherit;">
                <div class="card-header card-header-primary">
                  <!-- colors: "header-primary", "header-info", "header-success", "header-warning", "header-danger" -->
                  <div class="nav-tabs-navigation">
                    <div class="nav-tabs-wrapper">
                      <ul class="nav nav-tabs" data-tabs="tabs">
                        <li class="nav-item">
                          <a class="nav-link" href="contact.php">
                            <i class="material-icons">arrow_left</i> Back
                          </a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link active" href="#profile" data-toggle="tab">
                            <i class="material-icons">person_add</i>New Contact
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="card-body ">
                  <div class="tab-content text-center">
                    <div class="tab-pane active" id="profile">
<?php
/* Registration process, inserts user info into the database 
   and sends account confirmation email message
 */
if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
    if (isset($_POST['add_contact'])) {

// Escape all $_POST variables to protect against SQL injections
$contact_id = $mysqli->escape_string($_POST['contact_id']);
$first_name = $mysqli->escape_string($_POST['first_name']);
$last_name = $mysqli->escape_string($_POST['last_name']);
$company = $mysqli->escape_string($_POST['company']);
$phone_number1 = $mysqli->escape_string($_POST['phone_one']);
$phone_number2 = $mysqli->escape_string($_POST['phone_two']);
$contact_email = $mysqli->escape_string($_POST['contact_email']);
$gender = $mysqli->escape_string($_POST['gender']);
$notes = $mysqli->escape_string($_POST['notes']);
$diary_owner = $profile_email;


//$passwordo = $mysqli->escape_string(password_hash($_POST['password'], PASSWORD_BCRYPT));
//$hasho = $mysqli->escape_string( md5( rand(0,1000) ) );
    

  //  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);  
// Check if user with that email already exists
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
              // set the PDO error mode to exception
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$sql = "SELECT * FROM contacts WHERE contact_id='$contact_id'";

$result = $mysqli->query($sql) or die($mysqli->error());
// We know user number exists if the rows Discharged are more than 0
//$count = mysqli_num_rows($result);
if (mysqli_num_rows($result) > 0 ) { 

    try {
              $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
              // set the PDO error mode to exception
              $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
              $sql = "UPDATE contacts SET diary_owner='$diary_owner', contact_id='$contact_id', contact_first_name='$first_name', contact_last_name='$last_name', company='$company', phone_1='$phone_number1', phone_2='$phone_number2', email='$contact_email', gender='$gender', note='$notes' WHERE id='$btn_id'";
              $conn->exec($sql);
?>
<div class="section cd-section section-notifications" id="notifications">
      <div class="alert alert-success">
        <div class="container">
          <div class="alert-icon">
            <i class="material-icons">notification_important</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="material-icons">delete_sweep</i></span>
          </button>

          <b>New Contact <?php echo " Contact Updated Successfully"; ?></b>
        </div>
      </div>
<?php
              
 
              }
            catch(PDOException $e)
              {
              echo $sql . "<br>" . $e->getMessage();
              }

            $conn = null;
          

    }

}
}
?>

    
  <div class="container-fluid">
  <div class="row">
                      <div class="col-lg-6 col-sm-6">
                        <form action="edit-contact.php?btn_id=<?php echo($id);?>" method="POST" enctype="multipart/form-data" >
                           <input name="contact_id" class="form-control form-group" type="hidden" value="<?php echo $contact_id;?>"></br>
              <div class="form-group">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">person</i>
                    </span>
                  </div>
                  <input type="text" class="form-control" name="first_name" value="<?php echo $contact_first_name;?>" placeholder="First Name" required>
                </div>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">person</i>
                    </span>
                  </div>
                  <input type="text" class="form-control" name="last_name" value="<?php echo $contact_last_name;?>" placeholder="Last Name" required>
                </div>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">house</i>
                    </span>
                  </div>
                  <input type="text" class="form-control" name="company" value="<?php echo $company;?>" placeholder="Where does your contact work?">
                </div>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">mobile_screen_share</i>
                    </span>
                  </div>
                  <input type="number" class="form-control" name="phone_one" value="<?php echo $primary_phone;?>" placeholder="000-0000-000" required>
                </div>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">phone</i>
                    </span>
                  </div>
                  <input type="number" class="form-control" value="<?php echo $phone_2;?>" name="phone_two" placeholder="000-0000-000">
                </div>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">email</i>
                    </span>
                  </div>
                  <input type="email" class="form-control" name="contact_email" value="<?php echo $contact_email;?>" placeholder="your@email.com">
                </div>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">supervisor_account</i>
                    </span>
                  </div>
                  <select class="form-control" type="text"  value="<?php echo $gender;?>" name="gender">
                    <option value="<?php echo $gender;?>">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>

                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">add_comment</i>
                    </span>
                  </div>
                  <textarea class="form-control" name="notes" value="<?php echo $note;?>" placeholder="Start taking Note..."></textarea><hr>
                  
                </div><hr>
                <div class="text-center">
                <button type="submit" name="add_contact" class="btn btn-primary btn-block btn-lg" value="login"><span class="material-icons">person_add</span> Save Contact</button>
                </div>

                
                </div>
              </form>
              </div>

              <div class="col-lg-6 col-sm-6">
                
                
                        
              </div>
              </div>
</div>
            </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- End Tabs with icons on Card -->
      </div>
    </div>
  </div>
 <?php
//require "contact-detail-modal.php";
require 'view-note-modal.php';
require('js-files.php');
?>
</body>

</html>