 <?php
// Create connection

$zero = 0;
$select = "SELECT * FROM notes WHERE user_email='$profile_email'";
if($read = mysqli_query($conn,$select)){
$num = mysqli_num_rows($read);
if($num > 0){
$weekly_calls_made = $num;

}

else{
$weekly_calls_made = 0;

}
}

?>
 <?php
// Create connection

$zero = 0;
$select = "SELECT * FROM notes WHERE user_email='$profile_email' AND ratings='Good'";
if($read = mysqli_query($conn,$select)){
$num2 = mysqli_num_rows($read);
if($num2 > 0){
$positive_feedback = $num2;


}
else{
$positive_feedback = 0;

}
}


?>
 <?php
// Create connection

$zero = 0;
$select = "SELECT * FROM notes WHERE user_email='$profile_email' AND ratings='Needs Follow Up'";
if($read = mysqli_query($conn,$select)){
$num3 = mysqli_num_rows($read);
if($num3 > 0){
$need_follow_up = $num3;

}


else{
$need_follow_up = "0";

}}


?>

<div class="row">
<div class="col-md-6">
		<div class="row" id="modals">
	<div class="card">
			<div class="ct-chart"> <?php //include("notification.php");?></div>
		<div class="card-content">
			<h4 class="title"><span class="material-icons btn-success" style="font-size: 10pt;border-radius: 15px;">clock</span> Your next shift starts by <?php echo date('H:i:s A' , time());?></h4>
			<p class="category"><span class="text-success"><i class="fa fa-long-arrow-up"></i> 9  </span> Shifts this week</p>
<a href="add-note.php"><button type="button" class="btn btn-success"><span class="material-icons">clock</span> </button></a>
<a href="add-note.php"><button type="button" class="btn btn-primary"><span class="material-icons">request</span> </button></a>

		</div>
		</div>
	</div>
</div>
<div class="col-md-6">
		<div class="card-content">
			<h5>Upcoming Shifts</h5>
					<a href="work-area.php"><button class="btn btn-lg btn-block btn-default btn-wd" >
           <h1 class="material-icons"><?php echo date('D, d M - H:i:s A' , time());?>)</h1>
      </button></a>

		</div>
</div>
</div>

	