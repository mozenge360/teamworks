-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2019 at 08:19 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `realtorspage`
--

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `diary_owner` text NOT NULL,
  `contact_id` text NOT NULL,
  `contact_first_name` text NOT NULL,
  `contact_last_name` text NOT NULL,
  `company` text NOT NULL,
  `phone_1` varchar(255) NOT NULL,
  `phone_2` varchar(255) NOT NULL,
  `email` text NOT NULL,
  `gender` text NOT NULL,
  `note` text NOT NULL,
  `reminder_status` varchar(255) NOT NULL DEFAULT 'off',
  `remind_me_at` text NOT NULL,
  `calls_count` int(11) NOT NULL,
  `rating` text NOT NULL,
  `date` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `diary_owner`, `contact_id`, `contact_first_name`, `contact_last_name`, `company`, `phone_1`, `phone_2`, `email`, `gender`, `note`, `reminder_status`, `remind_me_at`, `calls_count`, `rating`, `date`) VALUES
(1, 'msi.mozenge@gmail.com', 'RTP/1828365251', 'Moses', 'Stephen', 'ASL', '08031523939', '08131523939', 'googleafrica@gmail.com', 'Male', '', 'off', '', 0, '', '2019-04-27 11:49:53.539605'),
(2, 'msi.mozenge@gmail.com', 'RTP/692760224', 'Davidson', 'Micah', 'ASL', '09057244784', '', 'davidson@gmail.com', 'Male', '', 'off', '', 0, '', '2019-04-30 10:01:49.200279');

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `id` int(11) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `contact_id` varchar(400) NOT NULL,
  `notes` text NOT NULL,
  `reminder_status` varchar(255) NOT NULL,
  `reminder_date` text NOT NULL,
  `ratings` varchar(255) NOT NULL,
  `date_time` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`id`, `user_email`, `contact_id`, `notes`, `reminder_status`, `reminder_date`, `ratings`, `date_time`) VALUES
(5, 'msi.mozenge@gmail.com', '1', 'THE CONTRACT AS STATED ABOVE WILL BE BOUND BY THE â€œMEMORANDUM OF AGREEMENTâ€ AND OTHER FORMS OF BINDING CONSENSUAL AGREEMENT BETWEEN BOTH PARTIES; CONTRACTOR AND CONTRACTED', '', '', 'Good', '2019-04-23 18:53:37.518968'),
(6, 'msi.mozenge@gmail.com', '1', 'THIS PROJECT WILL TAKE AN ESTIMATE 8 WEEKS, THE GANTT CHART BELOW DESCRIBES MILESTONES, TARGETS AND TIMELINES NECESSARY FOR THE COMPLETE DEVELOPMENT AND DEPLOYMENT OF THIS PROJECT.', '', '', 'Good', '2019-04-23 19:08:09.476198'),
(7, 'msi.mozenge@gmail.com', '1', 'THIS PROJECT WILL TAKE AN ESTIMATE 8 WEEKS, THE GANTT CHART BELOW DESCRIBES MILESTONES, TARGETS AND TIMELINES NECESSARY FOR THE COMPLETE DEVELOPMENT AND DEPLOYMENT OF THIS PROJECT.', '', '', 'Good', '2019-04-23 19:10:32.575298'),
(20, 'msi.mozenge@gmail.com', '1', 'Very Busy at the moment', 'on', '10/05/2016', 'Needs Follow Up', '2019-04-27 12:28:31.471336'),
(21, 'msi.mozenge@gmail.com', '1', '', 'off', '10/05/2016 12:00 AM', 'No Rating', '2019-04-30 18:44:27.867685');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(32) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `gender` varchar(32) NOT NULL,
  `user_id` varchar(32) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `hash` varchar(32) NOT NULL,
  `pin` int(11) NOT NULL,
  `register_date` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `identification_document` varchar(32) NOT NULL,
  `identification` varchar(32) NOT NULL,
  `user_phone_number` varchar(15) NOT NULL,
  `user_type` varchar(32) NOT NULL,
  `department` text NOT NULL,
  `picture` varchar(225) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `reg_date` text NOT NULL,
  `suspension_time` text NOT NULL,
  `browser` text NOT NULL,
  `ip` text NOT NULL,
  `last_login` text NOT NULL,
  `os` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `title`, `first_name`, `middle_name`, `last_name`, `gender`, `user_id`, `email`, `password`, `hash`, `pin`, `register_date`, `identification_document`, `identification`, `user_phone_number`, `user_type`, `department`, `picture`, `active`, `reg_date`, `suspension_time`, `browser`, `ip`, `last_login`, `os`) VALUES
(14, 'Proffessor', 'Moses', 'I.', 'STEPHEN', 'male', 'EUS/16074034040018', 'msi.mozenge@gmail.com', '$2y$10$iNQZnEuvHwwp7QViLzyuwuo64qBA5FvNRSwVdzAg/YkUeEmyDWPIq', '0353ab4cbed5beae847a7ff6e220b5cf', 1995, '2018-12-02 20:52:53.404237', 'Staff ID', 'SPA978725661278', '8131523939', 'super', 'Circulation', 'profile_pictures/5c044625623c64.54386718.jpg', 0, '', '', '', '', '', ''),
(15, '', 'David', '', '', '', '', 'davidson@gmail.com', '$2y$10$lOQtMGVRbZyPujahwuPDKuLTy.S6/cfXl7sXX1AN1BsPog0hKe/We', 'bcbe3365e6ac95ea2c0343a2395834dd', 0, '2019-04-27 12:59:12.395174', '', '', '', '', '', '', 0, '', '', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
