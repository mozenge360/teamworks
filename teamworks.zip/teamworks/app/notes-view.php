<?php
  require('head-tag.php');
  $id = $mysqli->escape_string($_GET["btn_id"]) ;
?>
<body class="profile-page sidebar-collapse">
<?php
  require('navigation-tag.php');
?>
  <div class="page-header header-filter" data-parallax="true" style="background-image: url('../assets/img/city-profile.jpg'); height: 150px;"></div>
  <div class="main main-raised">
    <div class="profile-content">
      <div class="container">

              <!-- Tabs with icons on Card -->
              <div class="card card-nav-tabs card-plain" style="widows: inherit;">
                <div class="card-header card-header-primary">
                  <div class="nav-tabs-navigation">
                    <div class="nav-tabs-wrapper">
                      <ul class="nav nav-tabs" data-tabs="tabs">
                        <li class="nav-item">
                          <a class="nav-link" href="dashboard.php?btn_id=<?php echo($id)?>">
                            <i class="material-icons">arrow_left</i> Back
                          </a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="notes-view.php?btn_id=<?php echo($id)?>" data-toggle="tab">
                            <i class="material-icons">note</i> Notes
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="card-body ">
                  <div class="tab-content text-center">
                    <div class="tab-pane active" id="profile">
                    <div class="card-body ">
                  <div class="tab-content text-center">
                    <div class="tab-pane active" id="profile">
                      <div class="description text-center">
                        <a href="add-note.php?btn_id=<?php echo($id);?>"><button type="button" class="btn btn-info"><span class="material-icons">reply</span> Reply</button></a>
                        <hr>
                        <p>All Notes taken will appear here...</p>
                        <hr>
<?php
if(isset($_SESSION["email"])){

$id = $mysqli->escape_string($_GET["btn_id"]) ;

$sql = "SELECT * FROM notes WHERE user_email='$profile_email' AND contact_id=$id";
if($readme = mysqli_query($conn,$sql)){
$num = mysqli_num_rows($readme);
if($num > 0){

  while($list = mysqli_fetch_array($readme)){
    $id =$list["id"];
    $diary_owner = $list["user_email"];
    $contact_ids = $list["contact_id"];           
    $contact_notes = $list["notes"];
    $contact_rate = $list["ratings"];
    $date = $list["date_time"];

      if ($contact_rate === "") {
        $contact_rate = "Rate Contact";
      }elseif($contact_rate === "Good"){
        $contact_rate = '<span class="material-icons" style="color:green;">checkbox</span>';
      }elseif($contact_rate === "Needs Follow Up"){
        $contact_rate = '<span class="material-icons"  style="color:orange;">report_off</span>';
      }elseif($contact_rate === "Not Interested at this time"){
        $contact_rate = '<span class="material-icons"  style="color:black;">work_off</span>';
      }

    ?>
                
                        <div class="tim-typo">
              <span class="tim-note"><?php echo "$contact_rate";?></span>
              <div class="blockquote undefined">
                <p>
                 <?php echo "$contact_notes";?>
                </p>
                <small>
                  <?php echo date('D, d M Y H:i:s A' , time($date));?>
                </small>
              </div>
            </div>
                       
                     
    <?php
}
}else{
echo "No notes yet!";
}

}else{
echo "Failed to query db!!";
}


}
else{
  //echo date('m/dY H:is' , time($date));
  //strtotime(time)
echo "Data failed";
}
?>
 </div>
                      
                    </div>
                    <div class="tab-pane" id="messages">
                     
                  

                    </div>
                  </div>
                </div>
              </div>
              <!-- End Tabs with icons on Card -->
      </div>
    </div>
  </div>
 
<?php
//require "contact-detail-modal.php";
require 'view-note-modal.php';
require('js-files.php');
?>
</body>

</html>