<?php
$myObj->provider_key1 = "The key of the first social network to publish the message to.
Example: facebook";
$myObj->provider_key2 = "The key of the second social network to publish the message to.
Example: twitter";
$myObj->user_token = "The unique token of the user to post the content for.Example: 9a76c7f6-3705-48a8-8ea6-e862ed86d5d8";
$myObj->text_body = "The text to be published on the social network.";
$myObj->video_url = "The URL of a video to be included in the publication.
Example: http://www.example.com/my_video.swf";
$myObj->picture_url = "The URL of a picture to be included in the publication.
Example: http://www.example.com/my_picture.png";
$myObj->link_url = " 	A link to be included in the publication.
Example: http://www.example.com/my_page.html";
$myObj->link_name = "The name of the included link.
Example: My page on example.com";
$myObj->link_caption = "The caption of the included link.
Example: Visit us for more";
$myObj->link_description = "The description of the included link.
Example: Our website is about examples.";
$myObj->upload_file_name = "The name of the file to be uploaded.
Example: image.png";
$myObj->upload_file_data = "The base64 encoded representation of the file data.
Example: ";
$myObj->flag_enable_tracking = "A flag to turn on (flag=1, default) or to turn off (flag=0) the automatic shortening of URLs included in the post.
Example: 0";




$myJSON = json_encode($myObj);

echo $myJSON;
?>