<?php

function find_id($x)
{
$id = $x;
if($id !== ""){

$sql = "SELECT * FROM contacts WHERE id='$id'";
if($readme = mysqli_query($conn,$sql)){
$num = mysqli_num_rows($readme);
if($num > 0){

  while($list = mysqli_fetch_array($readme)){
    $id =$list["id"];
    $diary_owner = $list["diary_owner"];
    $contact_id = $list["contact_id"];           
    $contact_first_name = $list["contact_first_name"];
    $contact_last_name = $list["contact_last_name"];
    $company = $list["company"];
    $primary_phone = $list["phone_1"];
    $phone_2 = $list["phone_2"];
    $contact_email = $list["email"];
    $gender = $list["gender"];
    $note = $list["note"];
    $calls_count = $list["calls_count"];
    $contact_rating = $list["rating"];

      if ($contact_email == "") {
        $contact_email = "#";
      }
      if ($calls_count == "") {
        $calls_count = 0;
      }
      if ($contact_rating == "") {
        $contact_rating = "Rate Contact";
      }

}
}else{
//echo "You do not have any contacts yet, Add Contact!";
}

}else{
//echo "Failed to query db!!";
}


}
else{
echo "Oops! No Internet Connection";
}
}
?>