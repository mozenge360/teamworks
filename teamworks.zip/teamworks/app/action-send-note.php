<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
    if (isset($_POST['add_note'])) {

// Escape all $_POST variables to protect against SQL injections
$contact_id = $mysqli->escape_string($_POST['contact_id']);
$note_added = $mysqli->escape_string($_POST['note_added']);
$contact_rating = $mysqli->escape_string($_POST['contact_rate']);
$reminder_status = $mysqli->escape_string($_POST['reminder_status']);
$reminder_date = $mysqli->escape_string($_POST['reminder_date']);
$diary_owner = $profile_email;

if ($reminder_status == "") {
  $reminder_status = "off";
}


if (isset($_SESSION["email"])) { 

    try {
              $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
              // set the PDO error mode to exception
              $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
              $sql = "INSERT INTO notes (user_email, contact_id, notes, reminder_status, reminder_date, ratings)
              VALUES ('$diary_owner', '$contact_id', '$note_added', '$reminder_status', '$reminder_date', '$contact_rating')";
             $conn->exec($sql);
              ?>
<div class="section cd-section section-notifications" id="notifications">
      <div class="alert alert-success">
        <div class="container">
          <div class="alert-icon">
            <i class="material-icons">add_alert</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="material-icons">delete_sweep</i></span>
          </button>

          <b>Note Added Successfully <?php echo "$reminder_status"; ?></b>
        </div>
      </div>
              <?php
 
              }
            catch(PDOException $e)
              {
              echo $sql . "<br>" . $e->getMessage();
              }

            $conn = null;
          

    }

}
}
?>