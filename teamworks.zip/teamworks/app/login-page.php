<?php
  require('head.php');
?>
<body class="login-page sidebar-collapse">
<?php
  //include('navigation-tag.php');
?>
  <div class="page-header header-filter" style="background-image: url('../assets/img/bg7.jpg'); background-size: cover; background-position: top center;">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-6 ml-auto mr-auto">
          <div class="card card-login">

            <form  action="login-page.php" method="POST" autocomplete="on"> 
              <div class="card-header card-header-primary text-center">
                <h4 class="card-title">Login</h4>
                
                <div class="social-line">
                  
                </div>
              </div>
              <p class="description text-center">Or Be Classical</p>
              <div class="card-body">
<?php
  if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
    if (isset($_POST['login'])) {
/* User login process, checks if user exists and password is correct */

// Escape email to protect against SQL injections
$email = $mysqli->escape_string($_POST['email']);
$result = $mysqli->query("SELECT * FROM users WHERE email='$email'");


if ( $result->num_rows == 0 ){ // User doesn't exist

    $_SESSION['message'] = "User with that email doesn't exist!";
    $err_msg = $_SESSION['message'];
                    echo "<div class='alert alert-danger'>";
                    echo "<h4>$err_msg <span class='glyphicon glyphicon-warning-sign'></span> </h4>";
                   echo "</div>";
}
else { // User exists
    $user = $result->fetch_assoc();

    if ( password_verify($_POST['password'], $user['password'])) {
            $_SESSION['title'] = $user['title'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['first_name'] = $user['first_name'];
            $_SESSION['middle_name'] = $user['middle_name'];
            $_SESSION['last_name'] = $user['last_name'];
            $_SESSION['phone'] = $user['user_phone_number'];
            $_SESSION['active'] = $user['active'];
            $_SESSION['user_type'] = $user['user_type'];
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['pin'] = $user['pin'];
            $_SESSION['identification'] = $user['identification'];
            $_SESSION['identification_document'] = $user['identification_document'];
            $_SESSION['picture'] = $user['picture'];
            $_SESSION['user_id'] = $user['user_id'];
             $_SESSION['department'] = $user['department'];
        // This is how we'll know the user is logged in
        $_SESSION['logged_in'] = true;
        header('location: dashboard.php');
    }
    elseif ( password_verify($_POST['password'], $user['password'])) {
        
            $_SESSION['title'] = $user['title'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['first_name'] = $user['first_name'];
            $_SESSION['middle_name'] = $user['middle_name'];
            $_SESSION['last_name'] = $user['last_name'];
            $_SESSION['active'] = $user['active'];
            $_SESSION['phone'] = $user['user_phone_number'];
            $_SESSION['user_type'] = $user['user_type'];
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['pin'] = $user['pin'];
            $_SESSION['identification'] = $user['identification'];
            $_SESSION['identification_document'] = $user['identification_document'];
            $_SESSION['picture'] = $user['picture'];
            $_SESSION['user_id'] = $user['user_id'];
             $_SESSION['department'] = $user['department'];
        // This is how we'll know the user is logged in
        $_SESSION['logged_in'] = true;
        header("location: dashboard.php");
    }
    else {
        $_SESSION['message'] = "You have entered wrong password, try again!";
    $err_msg = $_SESSION['message'];
                    echo "<div class='alert alert-danger'>";
                    echo "<h4>$err_msg <span class='fa fa fw fa-warning'></span> </h4>";
                   echo "</div>";
    }
}
}
}
?>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">mail</i>
                    </span>
                  </div>
                  <input type="email" name="email" required="required" class="form-control" placeholder="Email...">
                </div>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">lock_outline</i>
                    </span>
                  </div>
                  <input type="password" name="password" required="required" class="form-control" placeholder="Password...">
                </div>
              </div>
              <!--<div class="footer text-center">
                <a href="signup-page.php" class="btn btn-default btn-block btn-wd btn-lg">Haven't signed up yet? Get Started</a>
              </div>-->
              
              <div class="text-center">
                <button type="submit" name="login" class="btn btn-primary btn-block btn-lg" value="login">Login</button>
                </div>
                <a href="signup-page.php" class="btn btn-info btn-block btn-lg"> Haven't signed up yet?</a>
            </form>
          </div>
        </div>
      </div>
    </div> 
  </div>
<?php
  require('js-files.php');
?>  
</body>

</html>